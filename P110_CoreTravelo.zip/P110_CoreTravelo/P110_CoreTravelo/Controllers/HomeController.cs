﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P110_CoreTravelo.DAL;
using P110_CoreTravelo.Models;
using P110_CoreTravelo.ViewModel;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace P110_CoreTravelo.Controllers
{
    public class HomeController : Controller
    {
        private readonly TraveloDbContext _context;

        public HomeController(TraveloDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            HomeIndexVM viewModel = new HomeIndexVM()
            {
                Sliders = _context.Sliders,
                HoneyMoon = _context.HoneyMoon.First(),
                HoneymoonDestinations = _context.HoneymoonDestinations,
                Services = _context.Services,
                Blogs = _context.Blogs
            };

            //get language cookie here
            ViewBag.FavLang = Request.Cookies["fav_lang"];

            return View(viewModel);
        }

        public IActionResult AddToBasket(int? proId)
        {
            string currentJsonBasket = HttpContext.Session.GetString("basket");

            List<Product> userBasket = null;

            if(currentJsonBasket != null)
            {
                userBasket = JsonConvert.DeserializeObject<List<Product>>(currentJsonBasket);
            }
            else
            {
                userBasket = new List<Product>();
            }

            //userBasket.Add(_context.Products.Find(proId));
            string jsonBasket = JsonConvert.SerializeObject(userBasket);

            HttpContext.Session.SetString("basket", jsonBasket);

            return Content("added");
        }

        public IActionResult About()
        {
            string jsonBasket = HttpContext.Session.GetString("basket");

            List<Product> userBasket = JsonConvert.DeserializeObject<List<Product>>(jsonBasket);

            return Content("");
        }

        [Route("[controller]/[action]/{id}/{name}/{color}")]
        public IActionResult Contact(int id, string name, string color)
        {
            return Content($"samir {id} {name} {color}");
        }

        public IActionResult ChangeLang(string language)
        {
            HttpContext.Response.Cookies.Append("fav_lang", language, 
                new CookieOptions { MaxAge  = TimeSpan.FromSeconds(40) });

            return Ok(new
            {
                status = 200,
                error = "",
                data = ""
            });
        }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}