﻿using Microsoft.AspNetCore.Mvc;
using P110_CoreTravelo.DAL;
using P110_CoreTravelo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P110_CoreTravelo.ViewComponents
{
    public class DestinationsViewComponent : ViewComponent
    {
        private readonly TraveloDbContext _context;

        public DestinationsViewComponent(TraveloDbContext context)
        {
            _context = context;
        }

        public async Task<IViewComponentResult> InvokeAsync(int count)
        {
            var destinations = _context.Destinations.OrderByDescending(d => d.Id).Take(count);

            return View(await Task.FromResult(destinations));
        }
    }
}
