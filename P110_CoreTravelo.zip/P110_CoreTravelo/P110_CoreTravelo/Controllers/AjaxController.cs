﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P110_CoreTravelo.DAL;
using P110_CoreTravelo.Models;

namespace P110_CoreTravelo.Controllers
{
    public class AjaxController : Controller
    {
        private readonly TraveloDbContext _context;

        public AjaxController(TraveloDbContext context)
        {
            _context = context;
        }

        public IActionResult LoadDestinations(int skip)
        {
            var destinations = _context.Destinations.OrderByDescending(d => d.Id).Skip(skip).Take(4);
            return PartialView("_DestinationsPartial", destinations);
        }
    }
}